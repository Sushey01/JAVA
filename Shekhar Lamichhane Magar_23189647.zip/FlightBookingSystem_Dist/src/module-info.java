module FlightBookingSystem_Dist {
    exports bcu.cmp5332.bookingsystem.data;
    exports bcu.cmp5332.bookingsystem.gui;
    exports bcu.cmp5332.bookingsystem.model;
    exports bcu.cmp5332.bookingsystem.main;
    exports bcu.cmp5332.bookingsystem.commands;

    requires java.desktop;

}