package bcu.cmp5332.bookingsystem.main;

import bcu.cmp5332.bookingsystem.commands.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/**
 * The CommandParser class provides functionality to parse user input commands
 * and create corresponding Command objects based on the input.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class CommandParser {

    /**
     * Parses the input line and returns the appropriate Command object.
     * 
     * @param line The input command line from the user.
     * @return A Command object corresponding to the input command.
     * @throws IOException If an I/O error occurs while reading input.
     * @throws FlightBookingSystemException If there is an error in parsing the command.
     */
    public static Command parse(String line) throws IOException, FlightBookingSystemException {
        try {
            String[] parts = line.split(" ", 3);
            String cmd = parts[0];

            if (cmd.equals("addflight")) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
                System.out.print("Flight Number: ");
                String flightNumber = reader.readLine();
                System.out.print("Origin: ");
                String origin = reader.readLine();
                System.out.print("Destination: ");
                String destination = reader.readLine();
                System.out.print("Price: ");
                double price = Double.parseDouble(reader.readLine());
                System.out.print("Capacity: ");
                int capacity = Integer.parseInt(reader.readLine());

                LocalDate departureDate = parseDateWithAttempts(reader);
                return new AddFlight(flightNumber, origin, destination, price, capacity, departureDate);
            } else if (cmd.equals("addcustomer")) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
                System.out.print("Customer Name: ");
                String name = reader.readLine();
                System.out.print("Phone: ");
                String phone = reader.readLine();
                System.out.print("Email: ");
                String email = reader.readLine();
                return new AddCustomer(name, phone, email);
            } else if (cmd.equals("loadgui")) {
                return new LoadGUI();
            } else if (parts.length == 1) {
                if (line.equals("listflights")) {
                    return new ListFlights();
                } else if (line.equals("listcustomers")) {
                    return new ListCustomers();
                } else if (line.equals("help")) {
                    return new Help();
                }
            } else if (parts.length == 2) {
                int id = Integer.parseInt(parts[1]);

                if (cmd.equals("showflight")) {
                    return new ShowFlight(--id);
                } else if (cmd.equals("showcustomer")) {
                    return new ShowCustomer(--id);
                }
            } else if (parts.length == 3) {
                int customer_id = Integer.parseInt(parts[1]);
                int flight_id = Integer.parseInt(parts[2]);

                if (cmd.equals("addbooking")) {
                    return new AddBooking(customer_id, flight_id);
                } else if (cmd.equals("editbooking")) {
                    // Handle edit booking command (to be implemented)
                } else if (cmd.equals("cancelbooking")) {
                    return new CancelBooking(customer_id, flight_id);
                }
            }
        } catch (NumberFormatException ex) {
            // Catch if there is a number format exception
        }

        throw new FlightBookingSystemException("Invalid command.");
    }

    /**
     * Parses the departure date input from the user with a limited number of attempts.
     * 
     * @param br The BufferedReader object to read input from the user.
     * @param attempts The maximum number of attempts allowed to input a valid date.
     * @return The parsed LocalDate object representing the departure date.
     * @throws IOException If an I/O error occurs while reading input.
     * @throws FlightBookingSystemException If the provided departure date is incorrect after
     *         all attempts are exhausted.
     */
    private static LocalDate parseDateWithAttempts(BufferedReader br, int attempts) throws IOException, FlightBookingSystemException {
        if (attempts < 1) {
            throw new IllegalArgumentException("Number of attempts should be higher than 0");
        }
        while (attempts > 0) {
            attempts--;
            System.out.print("Departure Date (\"YYYY-MM-DD\" format): ");
            try {
                LocalDate departureDate = LocalDate.parse(br.readLine());
                if (departureDate.isAfter(LocalDate.now()) || departureDate.isEqual(LocalDate.now())) {
                    return departureDate;
                } else {
                    System.out.println("Date should be after " + LocalDate.now() + ". " + attempts + " attempts remaining...");
                }
            } catch (DateTimeParseException dtpe) {
                System.out.println("Date must be in YYYY-MM-DD format. " + attempts + " attempts remaining...");
            }
        }

        throw new FlightBookingSystemException("Incorrect departure date provided. Cannot create flight.");
    }

    /**
     * Parses the departure date input from the user with a default number of attempts (3).
     * 
     * @param br The BufferedReader object to read input from the user.
     * @return The parsed LocalDate object representing the departure date.
     * @throws IOException If an I/O error occurs while reading input.
     * @throws FlightBookingSystemException If the provided departure date is incorrect after
     *         all attempts are exhausted.
     */
    private static LocalDate parseDateWithAttempts(BufferedReader br) throws IOException, FlightBookingSystemException {
        return parseDateWithAttempts(br, 3);
    }
}
