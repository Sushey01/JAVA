package bcu.cmp5332.bookingsystem.main;

/**
 * FlightBookingSystemException extends {@link Exception} class and is a custom exception
 * that is used to notify the user about errors or invalid commands.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class FlightBookingSystemException extends Exception {

    /**
     * Constructs a new FlightBookingSystemException with the specified detail message.
     * 
     * @param message The detail message (which is saved for later retrieval by the {@link #getMessage()} method).
     */
    public FlightBookingSystemException(String message) {
        super(message);
    }
}
