package bcu.cmp5332.bookingsystem.main;

/**
 * CustomerException extends {@link Exception} class and is a custom exception
 * that is used to notify the user about errors or invalid commands.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class CustomerException extends Exception {

    /**
     * Constructs a new CustomerException with the specified detail message.
     * 
     * @param message The detail message (which is saved for later retrieval by the {@link #getMessage()} method).
     */
    public CustomerException(String message) {
        super(message);
    }
}
