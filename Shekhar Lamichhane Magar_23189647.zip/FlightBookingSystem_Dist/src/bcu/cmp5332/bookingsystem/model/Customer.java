package bcu.cmp5332.bookingsystem.model;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import java.util.ArrayList;
import java.util.List;

public class Customer {
    
    private int id;
    private String name;
    private String phone;
    private String email;
    private boolean isRemoved;
    private final List<Booking> bookings = new ArrayList<>();
    
    // TODO: implement constructor here
    public Customer(int id,String name,String phone,String email){
    	this(id, name, phone, email, false);
    }
    
    public Customer(int id,String name,String phone,String email, Boolean isRemoved){
    	this.id = id;
    	this.name = name;
    	this.phone = phone;
    	this.email = email;
    	this.isRemoved = isRemoved;
    }
    
    
    public boolean isRemoved() {
    	return this.isRemoved;
    }
    
    public void removeCustomer() {
    	this.isRemoved = true;
    }
    
    public String getEmail() {
    	return this.email;
    }
    
    public void setEmail(String newEmail) {
    	this.email = newEmail;
    }
    
    // TODO: implementation of Getter and Setter methods
    public int getId() {
    	return this.id;
    }
    
    public List<Booking> getBooking(){
    	return bookings;
    }
    
    public String getDetailsShort() {
        return "Customer ID #" + id + ", Name - " + name + ", Phone - " + phone;
    }
    
    public String getDetailsLong() {
    	String result =	 "Customer ID #" + id + "\nName: " + name +"\nEmail: "+ email + "\nPhone: " + phone + "\n-----------------\nBookings:";
    	int counter = 0;
    	if(!bookings.isEmpty()) {
    		for (Booking booking : bookings) {
    		    result += "\n* Booking date: "+booking.getBookingDate()+" for Flight #"+booking.getFlight().getId()+ " - "+booking.getFlight().getFlightNumber()+" - "+booking.getFlight().getOrigin() + " to "+booking.getFlight().getDestination() +" on "+booking.getFlight().getDepartureDate() + ". Price: Rs."+booking.getPrice();
    		    counter++;
    		}
    		result += "\n"+counter + " booking(s)";
    	}else {
    		result += "\n No Booking has been made by this customer";
    		result += "\n"+counter + " booking(s)";
    	}
    	return result;
    }
    
    public String getName() {
    	return this.name;
    }
    
    public String getPhone() {
    	return this.phone;
    }
    
    public void setId(int newId) {
    	this.id = newId;
    }
    
    public void setName(String newName) {
    	this.name = newName;
    }
    
    public void setPhone(String newPhone) {
    	this.phone = newPhone;
    }
    
    public void addBooking(Booking booking) {
    	bookings.add(booking);
        // TODO: implementation here
    }
    public void cancelBooking(Booking booking) {
    	bookings.remove(booking);
    }
}
