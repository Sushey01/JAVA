package bcu.cmp5332.bookingsystem.model;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
public class Flight {
    
    private int id;
    private String flightNumber;
    private String origin;
    private String destination;
    private double price;
    private int capacity;
    private boolean isRemoved;
    private LocalDate departureDate;

    private final Set<Customer> passengers;

    public Flight(int id, String flightNumber, String origin, String destination, double price, int capacity, LocalDate departureDate, boolean isRemoved) {
        this.id = id;
        this.flightNumber = flightNumber;
        this.origin = origin;
        this.destination = destination;
        this.price = price;
        this.capacity = capacity;
        this.departureDate = departureDate;
        this.isRemoved = isRemoved;
        passengers = new HashSet<>();
    }

    public Flight(int id, String flightNumber, String origin, String destination, double price, int capacity, LocalDate departureDate) {
        this(id, flightNumber, origin, destination, price, capacity, departureDate, false);
    }
    
    public double getPrice() {
    	return this.price;
    }
    
    public boolean isRemoved() {
    	return this.isRemoved;
    }
    
    public void removeFlight() {
    	this.isRemoved = true;
    }
    
    public void setPrice(double newPrice) {
    	this.price = newPrice;
    }
    
    public void setCapacity(int newCapacity) {
    	this.capacity = newCapacity;
    }
    
    public int getCapacity() {
    	return this.capacity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFlightNumber() {
        return flightNumber;
    }
    
    public int getRemainingCapacity() {
    	return capacity -  passengers.size();
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }
    
    public String getOrigin() {
        return origin;
    }
    
    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public LocalDate getDepartureDate() {
        return departureDate;
    }

    public void setDepartureDate(LocalDate departureDate) {
        this.departureDate = departureDate;
    }

    public List<Customer> getPassengers() {
        return new ArrayList<>(passengers);
    }
	
    public String getDetailsShort() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return "Flight #" + id + " - " + flightNumber + " - " + origin + " to " 
                + destination + " on " + departureDate.format(dtf) + " Price: "+Booking.calculateDynamicPrice(this);
    }

    public String getDetailsLong() {
        String result = "Flight #"+getId()+"\nFlight No: "+getFlightNumber()+"\nOrigin: "+getOrigin()+"\nDestination: "+getDestination()+ "\nBase Price (Original for flight): "+ getPrice() + "\nCapacity :" + capacity + "\nRemaining Capacity :" + getRemainingCapacity() +  "\nDeparture Date: "+getDepartureDate() + "\n-------------\nPassengers:\n";
        int counter = 0;
    	if(!passengers.isEmpty()) {
    		for (Customer passenger : passengers) {
    		    result += "\n* Id: "+passenger.getId()+" - " + passenger.getName()+ " - " + passenger.getPhone() + " - Rs." ;
    		    List<Booking> bookings = passenger.getBooking();
    		    for( Booking booking : bookings) {
    		    	if(booking.getFlight() == this) {
    		    		result += booking.getPrice();
    		    	}
    		    }
    		    counter++;
    		}
    		result += "\n"+counter + " passenger(s)";
    	}else {
    		result += "\n No Booking has been made till  date";
    		result += "\n"+counter + " passenger(s)";
    	}
        return result;
    }
    
    public void addPassenger(Customer passenger) {
        passengers.add(passenger);
    }
    
    public void removePassenger(Customer passenger) {
        passengers.remove(passenger);
    }
    
}
