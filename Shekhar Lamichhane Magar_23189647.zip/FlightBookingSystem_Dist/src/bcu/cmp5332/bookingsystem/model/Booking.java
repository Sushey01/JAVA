package bcu.cmp5332.bookingsystem.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * The Booking class represents a booking made by a customer for a flight.
 * It contains information about the booking such as the customer, flight,
 * booking date, and price.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class Booking {
    
    private int id;
    private Customer customer;
    private Flight flight;
    private LocalDate bookingDate;
    private double price;

    /**
     * Constructs a Booking object with the specified parameters.
     * 
     * @param id The unique identifier for the booking.
     * @param customer The customer who made the booking.
     * @param flight The flight booked by the customer.
     * @param bookingDate The date when the booking was made.
     * @param price The price paid for the booking.
     */
    public Booking(int id, Customer customer, Flight flight, LocalDate bookingDate, double price) {
        this.id = id;
        this.customer = customer;
        this.flight = flight;
        this.bookingDate = bookingDate;
        this.price = price;
    }
    
    /**
     * Sets a new price for the booking.
     * 
     * @param newPrice The new price to be set for the booking.
     */
    public void setPrice(double newPrice) {
        this.price = newPrice;
    }
    
    /**
     * Calculates a dynamic price adjustment based on the remaining days until departure.
     * 
     * @param flight The flight for which to calculate the dynamic price adjustment.
     * @return The adjusted price based on the flight's current price and days until departure.
     */
    public static double calculateDynamicPrice(Flight flight) {
        double basePrice = flight.getPrice();
        int daysUntilDeparture = (int) ChronoUnit.DAYS.between(LocalDate.now(), flight.getDepartureDate());
        
        // Adjust price based on days until departure
        if (daysUntilDeparture <= 2) {
            basePrice *= 1.7; 
        } else if (daysUntilDeparture <= 7) {
            basePrice *= 1.4;
        } else if (daysUntilDeparture <= 30) {
            basePrice *= 1.1; 
        }
        
        // You can further adjust price based on remaining capacity if needed
        
        return basePrice;
    }
    
    /**
     * Retrieves the price of the booking.
     * 
     * @return The price of the booking.
     */
    public double getPrice() {
        return this.price;
    }

    /**
     * Retrieves the customer who made the booking.
     * 
     * @return The customer who made the booking.
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * Sets a new customer for the booking.
     * 
     * @param customer The new customer to be set for the booking.
     */
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    /**
     * Retrieves the flight booked by the customer.
     * 
     * @return The flight booked by the customer.
     */
    public Flight getFlight() {
        return flight;
    }

    /**
     * Sets a new flight for the booking.
     * 
     * @param flight The new flight to be set for the booking.
     */
    public void setFlight(Flight flight) {
        this.flight = flight;
    }
    
    /**
     * Retrieves the unique identifier of the booking.
     * 
     * @return The unique identifier of the booking.
     */
    public int getId() {
        return id; 
    }
    
    /**
     * Retrieves the date when the booking was made.
     * 
     * @return The date when the booking was made.
     */
    public LocalDate getBookingDate() {
        return bookingDate;
    }

    /**
     * Sets a new booking date for the booking.
     * 
     * @param bookingDate The new booking date to be set for the booking.
     */
    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }
}
