package bcu.cmp5332.bookingsystem.model;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.main.CustomerException;
import java.time.LocalDate;
import java.util.*;

/**
 * The FlightBookingSystem class represents the core system for managing flights, customers, and bookings.
 * It provides methods to add and retrieve flights, customers, and bookings, as well as manage operations
 * related to these entities.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class FlightBookingSystem {
    
    private final LocalDate systemDate = LocalDate.now();
    
    private final Map<Integer, Customer> customers = new TreeMap<>();
    private final Map<Integer, Flight> flights = new TreeMap<>();
    private final Map<Integer, Booking> bookings = new TreeMap<>();

    /**
     * Retrieves the current system date.
     * 
     * @return The current system date.
     */
    public LocalDate getSystemDate() {
        return systemDate;
    }
    
    /**
     * Retrieves a list of all flights in the system.
     * 
     * @return A list of all flights in the system.
     */
    public List<Flight> getFlights() {
        List<Flight> out = new ArrayList<>(flights.values());
        return Collections.unmodifiableList(out);
    }

    /**
     * Retrieves a flight by its unique identifier.
     * 
     * @param id The unique identifier of the flight to retrieve.
     * @return The flight with the specified ID.
     * @throws FlightBookingSystemException If no flight exists with the specified ID.
     */
    public Flight getFlightByID(int id) throws FlightBookingSystemException {
        if (!flights.containsKey(id)) {
            throw new FlightBookingSystemException("There is no flight with that ID.");
        }
        return flights.get(id);
    }

    /**
     * Retrieves a list of all customers in the system.
     * 
     * @return A list of all customers in the system.
     */
    public List<Customer> getCustomers() {
        List<Customer> out = new ArrayList<>(customers.values());
        return Collections.unmodifiableList(out);
    }
    
    /**
     * Retrieves a customer by their unique identifier.
     * 
     * @param id The unique identifier of the customer to retrieve.
     * @return The customer with the specified ID.
     * @throws CustomerException If no customer exists with the specified ID.
     */
    public Customer getCustomerByID(int id) throws CustomerException {
        if (!customers.containsKey(id)) {
            throw new CustomerException("There is no customer with that ID.");
        }
        return customers.get(id);
    }

    /**
     * Retrieves a list of all bookings in the system.
     * 
     * @return A list of all bookings in the system.
     */
    public List<Booking> getBookings() {
        List<Booking> out = new ArrayList<>(bookings.values());
        return Collections.unmodifiableList(out);
    }
    
    /**
     * Cancels a booking and removes it from the system.
     * 
     * @param booking The booking to be canceled and removed.
     */
    public void cancelBooking(Booking booking) {
        bookings.remove(booking.getId());
    }
    
    /**
     * Adds a new booking to the system.
     * 
     * @param booking The booking to be added to the system.
     * @throws FlightBookingSystemException If there is an issue adding the booking (e.g., duplicate ID).
     */
    public void addBooking(Booking booking) throws FlightBookingSystemException {
        bookings.put(booking.getId(), booking);
    }
    
    /**
     * Adds a new flight to the system.
     * 
     * @param flight The flight to be added to the system.
     * @throws FlightBookingSystemException If there is an issue adding the flight (e.g., duplicate ID or conflicting flight details).
     */
    public void addFlight(Flight flight) throws FlightBookingSystemException {
        if (flights.containsKey(flight.getId())) {
            throw new IllegalArgumentException("Duplicate flight ID.");
        }
        for (Flight existing : flights.values()) {
            if (existing.getFlightNumber().equals(flight.getFlightNumber()) 
                && existing.getDepartureDate().isEqual(flight.getDepartureDate())) {
                throw new FlightBookingSystemException("There is a flight with same "
                        + "number and departure date in the system");
            }
        }
        flights.put(flight.getId(), flight);
    }

    /**
     * Adds a new customer to the system.
     * 
     * @param customer The customer to be added to the system.
     * @throws CustomerException If there is an issue adding the customer (e.g., duplicate ID or conflicting customer details).
     */
    public void addCustomer(Customer customer) throws CustomerException {
        if (customers.containsKey(customer.getId())) {
            throw new IllegalArgumentException("Duplicate Customer ID.");
        }
        for (Customer existing : customers.values()) {
            if (existing.getPhone().equals(customer.getPhone()) 
                && existing.getName().equals(customer.getName())) {
                throw new CustomerException("There is a customer with same "
                        + "name and phone in the system");
            }
        }
        customers.put(customer.getId(), customer);
    }
}
