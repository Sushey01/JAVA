package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.commands.AddCustomer;
import bcu.cmp5332.bookingsystem.commands.Command;
import bcu.cmp5332.bookingsystem.main.CustomerException;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.data.FlightBookingSystemData;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

/**
 * Represents a window for adding a new customer to the flight booking system.
 * This window contains input fields for customer name, email, and phone number.
 * It allows the user to add a new customer or cancel the operation.
 *
 * @author Krishu Karki
 * @author Shekhar
 */
public class AddCustomerWindow extends JFrame implements ActionListener {

    private MainWindow mw;
    private JTextField nameText = new JTextField();
    private JTextField emailText = new JTextField();
    private JTextField phoneText = new JTextField();
    private JButton addBtn = new JButton("Add");
    private JButton cancelBtn = new JButton("Cancel");

    /**
     * Constructs an AddCustomerWindow object.
     *
     * @param mw the main window of the application
     */
    public AddCustomerWindow(MainWindow mw) {
        this.mw = mw;
        initialize();
    }

    /**
     * Initializes the contents of the frame.
     * Sets up GUI components such as text fields, buttons, and panels.
     */
    private void initialize() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            // Handle look and feel exception
        }

        setTitle("Add a New Customer");
        setSize(350, 220);

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(4, 2));
        topPanel.add(new JLabel("Name : "));
        topPanel.add(nameText);
        topPanel.add(new JLabel("Email : "));
        topPanel.add(emailText);
        topPanel.add(new JLabel("Phone : "));
        topPanel.add(phoneText);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new GridLayout(1, 3));
        bottomPanel.add(new JLabel("     "));
        bottomPanel.add(addBtn);
        bottomPanel.add(cancelBtn);

        addBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        getContentPane().add(topPanel, BorderLayout.CENTER);
        getContentPane().add(bottomPanel, BorderLayout.SOUTH);
        setLocationRelativeTo(mw);
        setVisible(true);
    }

    /**
     * Handles action events for buttons.
     * If Add button is clicked, it retrieves input values and attempts to add a new customer.
     * If Cancel button is clicked, it hides (closes) the AddCustomerWindow.
     *
     * @param ae the action event representing the user's interaction with GUI components
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == addBtn) {
            try {
                addCustomer();
            } catch (CustomerException | IOException | FlightBookingSystemException e) {
                JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        } else if (ae.getSource() == cancelBtn) {
            this.setVisible(false);
        }
    }
    /**
     * Attempts to add a new customer to the flight booking system.
     * Retrieves input values from text fields, creates an AddCustomer command,
     * and executes it using the flight booking system.
     * Updates the customer list in the main window and closes the AddCustomerWindow.
     *
     * @throws CustomerException         if there is an error with customer data
     * @throws IOException               if there is an I/O error while accessing data
     * @throws FlightBookingSystemException if there is an error with the flight booking system
     */
    private void addCustomer() throws CustomerException, IOException, FlightBookingSystemException {
        String name = nameText.getText();
        String email = emailText.getText();
        String phone = phoneText.getText();

        Command addCustomerCommand = new AddCustomer(name, phone, email);
        addCustomerCommand.execute(mw.getFlightBookingSystem());

        FlightBookingSystemData.store(mw.getFlightBookingSystem()); // Save updated data

        mw.displayCustomers(); // Refresh customer list in main window
        this.setVisible(false); // Close AddCustomerWindow
    }
}