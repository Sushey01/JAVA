package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.commands.CancelBooking;
import bcu.cmp5332.bookingsystem.commands.Command;
import bcu.cmp5332.bookingsystem.data.FlightBookingSystemData;
import bcu.cmp5332.bookingsystem.main.CustomerException;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

/**
 * The CancelBookingWindow class represents a graphical user interface window for canceling a booking.
 * It allows users to enter customer ID and flight ID to cancel a booking.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class CancelBookingWindow extends JFrame implements ActionListener {

    private MainWindow mw;
    private JTextField customerId = new JTextField();
    private JTextField flightId = new JTextField();
    private JButton cancelBookingBtn = new JButton("Cancel Booking");
    private JButton cancelBtn = new JButton("Exit");

    /**
     * Constructs a CancelBookingWindow object with a reference to the MainWindow.
     * 
     * @param mw The MainWindow instance that manages this window.
     */
    public CancelBookingWindow(MainWindow mw) {
        this.mw = mw;
        initialize();
    }

    /**
     * Initializes the GUI components of the window.
     */
    private void initialize() {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            // Handle look and feel exception
        }

        setTitle("Cancel Booking");

        setSize(350, 220);
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(4, 2));
        topPanel.add(new JLabel("Customer ID : "));
        topPanel.add(customerId);
        topPanel.add(new JLabel("Flight ID : "));
        topPanel.add(flightId);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new GridLayout(1, 3));
        bottomPanel.add(new JLabel("     "));
        bottomPanel.add(cancelBookingBtn);
        bottomPanel.add(cancelBtn);

        cancelBookingBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        getContentPane().add(topPanel, BorderLayout.CENTER);
        getContentPane().add(bottomPanel, BorderLayout.SOUTH);
        setLocationRelativeTo(mw);

        setVisible(true);

    }

    /**
     * Handles action events from the Cancel Booking and Exit buttons.
     * 
     * @param ae The ActionEvent object representing the action performed.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == cancelBookingBtn) {
            try {
                cancelBooking();
            } catch (CustomerException | IOException ex) {
                ex.printStackTrace(); // Temporary handling; should be improved
            }
        } else if (ae.getSource() == cancelBtn) {
            setVisible(false);
        }
    }

    /**
     * Cancels a booking based on the entered customer ID and flight ID.
     * It uses the CancelBooking command to execute the cancellation of the booking.
     * 
     * @throws CustomerException If there's an error related to customer data.
     * @throws IOException If an I/O error occurs while accessing data.
     */
    private void cancelBooking() throws CustomerException, IOException {
        try {
            int customerID = Integer.parseInt(customerId.getText());
            int flightID = Integer.parseInt(flightId.getText());

            Command cancelBookingCommand = new CancelBooking(customerID, flightID);
            cancelBookingCommand.execute(mw.getFlightBookingSystem());

            FlightBookingSystemData.store(mw.getFlightBookingSystem());

            setVisible(false);
        } catch (FlightBookingSystemException ex) {
            JOptionPane.showMessageDialog(this, ex, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
