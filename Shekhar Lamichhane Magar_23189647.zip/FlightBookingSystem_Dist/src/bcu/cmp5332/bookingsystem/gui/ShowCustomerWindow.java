package bcu.cmp5332.bookingsystem.gui;

import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;

import bcu.cmp5332.bookingsystem.model.Booking;
import bcu.cmp5332.bookingsystem.model.Customer;

/**
 * The ShowCustomerWindow class represents a graphical window that displays
 * details of a specific customer, including their ID, name, email, phone number,
 * and their bookings if any.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class ShowCustomerWindow extends JFrame {

    private JLabel customerID;
    private JLabel customerName;
    private JLabel customerEmail;
    private JLabel customerPhone;
    private JLabel customerBooking;

    /**
     * Constructs a ShowCustomerWindow object to display details of the given Customer.
     * 
     * @param customer The Customer object whose details are to be displayed.
     */
    public ShowCustomerWindow(Customer customer) {
        super("Customer Details");
        setSize(650, 600);
        setLocation(100, 50);
        setVisible(true);
        Container contentPane = getContentPane();
        contentPane.setLayout(new GridLayout(6, 1));

        customerID = new JLabel("Customer ID: " + customer.getId());
        customerName = new JLabel("Customer Name: " + customer.getName());
        customerEmail = new JLabel("Customer Email: " + customer.getEmail());
        customerPhone = new JLabel("Customer Phone: " + customer.getPhone());

        String result = "<html>Customer Bookings: <br>";
        int counter = 0;
        for (Booking booking : customer.getBooking()) {
            counter += 1;
            result += "<br>* Booking date: " + booking.getBookingDate() + " for Flight #" + booking.getFlight().getId()
                    + " - " + booking.getFlight().getFlightNumber() + " - " + booking.getFlight().getOrigin()
                    + " to " + booking.getFlight().getDestination() + " on " + booking.getFlight().getDepartureDate()
                    + ". Price: Rs." + booking.getPrice();
        }
        if (counter == 0) {
            result += "No booking made yet.";
        }
        customerBooking = new JLabel(result);

        contentPane.add(customerID);
        contentPane.add(customerName);
        contentPane.add(customerEmail);
        contentPane.add(customerPhone);
        contentPane.add(customerBooking);
    }
}
