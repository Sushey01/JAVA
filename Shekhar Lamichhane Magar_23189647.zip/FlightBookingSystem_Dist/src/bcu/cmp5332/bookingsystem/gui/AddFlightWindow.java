package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.commands.AddFlight;
import bcu.cmp5332.bookingsystem.commands.Command;
import bcu.cmp5332.bookingsystem.data.FlightBookingSystemData;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.main.CustomerException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/**
 * The AddFlightWindow class represents a graphical user interface window for adding a new flight.
 * It allows users to enter flight details including flight number, origin, destination, departure date,
 * price, and capacity.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class AddFlightWindow extends JFrame implements ActionListener {

    private MainWindow mw;
    private JTextField flightNoText = new JTextField();
    private JTextField originText = new JTextField();
    private JTextField destinationText = new JTextField();
    private JTextField depDateText = new JTextField();
    private JTextField flightPrice = new JTextField();
    private JTextField flightCapacity = new JTextField();
    private JButton addBtn = new JButton("Add");
    private JButton cancelBtn = new JButton("Cancel");

    /**
     * Constructs an AddFlightWindow object with a reference to the MainWindow.
     * 
     * @param mw The MainWindow instance that manages this window.
     */
    public AddFlightWindow(MainWindow mw) {
        this.mw = mw;
        initialize();
    }

    /**
     * Initializes the GUI components of the window.
     */
    private void initialize() {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            // Handle look and feel exception
        }

        setTitle("Add a New Flight");

        setSize(350, 220);
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(7, 2));
        topPanel.add(new JLabel("Flight No : "));
        topPanel.add(flightNoText);
        topPanel.add(new JLabel("Origin : "));
        topPanel.add(originText);
        topPanel.add(new JLabel("Destination : "));
        topPanel.add(destinationText);
        topPanel.add(new JLabel("Departure Date (YYYY-MM-DD) : "));
        topPanel.add(depDateText);
        topPanel.add(new JLabel("Price : "));
        topPanel.add(flightPrice);
        topPanel.add(new JLabel("Capacity : "));
        topPanel.add(flightCapacity);
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new GridLayout(1, 3));
        bottomPanel.add(new JLabel("     "));
        bottomPanel.add(addBtn);
        bottomPanel.add(cancelBtn);

        addBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        getContentPane().add(topPanel, BorderLayout.CENTER);
        getContentPane().add(bottomPanel, BorderLayout.SOUTH);
        setLocationRelativeTo(mw);

        setVisible(true);

    }

    /**
     * Handles action events from the Add and Cancel buttons.
     * 
     * @param ae The ActionEvent object representing the action performed.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == addBtn) {
            try {
                try {
					addFlight();
				} catch (CustomerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            } catch (FlightBookingSystemException | IOException ex) {
                ex.printStackTrace(); // Temporary handling; should be improved
            }
        } else if (ae.getSource() == cancelBtn) {
            setVisible(false);
        }
    }

    /**
     * Creates a new flight based on the input fields (flight number, origin, destination, departure date,
     * price, and capacity). It uses the AddFlight command to execute the addition of the flight.
     * 
     * @throws FlightBookingSystemException If there's an error related to flight data.
     * @throws IOException If an I/O error occurs while accessing data.
     * @throws CustomerException 
     */
    private void addFlight() throws FlightBookingSystemException, IOException, CustomerException {
        try {
            String flightNumber = flightNoText.getText();
            String origin = originText.getText();
            String destination = destinationText.getText();
            LocalDate departureDate = LocalDate.parse(depDateText.getText());
            Double price = Double.parseDouble(flightPrice.getText());
            int capacity = Integer.parseInt(flightCapacity.getText());

            Command addFlightCommand = new AddFlight(flightNumber, origin, destination, price, capacity, departureDate);
            addFlightCommand.execute(mw.getFlightBookingSystem());

            FlightBookingSystemData.store(mw.getFlightBookingSystem());

            // Refresh the view with the list of flights
            mw.displayFlights();

            // Close the AddFlightWindow after successfully adding a flight
            setVisible(false);
        } catch (DateTimeParseException dtpe) {
            throw new FlightBookingSystemException("Date must be in YYYY-MM-DD format");
        }
    }

}
