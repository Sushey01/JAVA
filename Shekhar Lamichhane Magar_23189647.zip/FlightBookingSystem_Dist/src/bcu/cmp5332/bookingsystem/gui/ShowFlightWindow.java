package bcu.cmp5332.bookingsystem.gui;

import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import bcu.cmp5332.bookingsystem.model.Booking;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Flight;

/**
 * The ShowFlightWindow class represents a graphical window that displays details
 * of a specific flight, including the list of passengers and their booking details.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class ShowFlightWindow extends JFrame {

    /**
     * Constructs a ShowFlightWindow object to display details of the given Flight.
     * 
     * @param flight The Flight object whose details are to be displayed.
     */
    public ShowFlightWindow(Flight flight) {
        super("Flight Details");
        setSize(580, 420);
        setVisible(true);
        Container contentPane = getContentPane();

        // Define table columns
        String[] columns = new String[]{"Customer ID", "Name", "Email", "Phone Number", "Price"};

        // Prepare data for the table
        Object[][] data = new Object[flight.getPassengers().size()][5];
        for (int i = 0; i < flight.getPassengers().size(); i++) {
            Customer customer = flight.getPassengers().get(i);
            data[i][0] = customer.getId();
            data[i][1] = customer.getName();
            data[i][2] = customer.getEmail();
            data[i][3] = customer.getPhone();

            // Find the booking for this flight and retrieve its price
            for (Booking booking : customer.getBooking()) {
                if (booking.getFlight() == flight) {
                    data[i][4] = booking.getPrice();
                }
            }
        }

        // Create the table and add it to the frame
        JTable table = new JTable(data, columns);
        contentPane.removeAll();
        contentPane.add(new JScrollPane(table));
        revalidate();
    }
}
