package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.commands.AddBooking;
import bcu.cmp5332.bookingsystem.commands.Command;
import bcu.cmp5332.bookingsystem.data.FlightBookingSystemData;
import bcu.cmp5332.bookingsystem.main.CustomerException;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

/**
 * The AddBookingWindow class represents a graphical user interface window for adding a new booking.
 * It allows users to enter customer ID and flight ID to create a new booking.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class AddBookingWindow extends JFrame implements ActionListener {

    private MainWindow mw;
    private JTextField customerId = new JTextField();
    private JTextField flightId = new JTextField();
    private JButton addBtn = new JButton("Add Booking");
    private JButton cancelBtn = new JButton("Cancel");

    /**
     * Constructs an AddBookingWindow object with a reference to the MainWindow.
     * 
     * @param mw The MainWindow instance that manages this window.
     */
    public AddBookingWindow(MainWindow mw) {
        this.mw = mw;
        initialize();
    }

    /**
     * Initializes the GUI components of the window.
     */
    private void initialize() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            // Handle look and feel exception
        }

        setTitle("Add a New Booking");
        setSize(350, 220);

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(2, 2));
        topPanel.add(new JLabel("Customer ID : "));
        topPanel.add(customerId);
        topPanel.add(new JLabel("Flight ID : "));
        topPanel.add(flightId);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(addBtn);
        bottomPanel.add(cancelBtn);

        addBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(topPanel, BorderLayout.CENTER);
        getContentPane().add(bottomPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(mw);
        setVisible(true);
    }

    /**
     * Handles action events from the Add Booking and Cancel buttons.
     * 
     * @param ae The ActionEvent object representing the action performed.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == addBtn) {
            try {
                addBooking();
            } catch (CustomerException | IOException ex) {
                ex.printStackTrace(); // Temporary handling; should be improved
            }
        } else if (ae.getSource() == cancelBtn) {
            setVisible(false);
        }
    }

    /**
     * Creates a new booking based on the customer ID and flight ID entered.
     * It uses the AddBooking command to execute the addition of the booking.
     * 
     * @throws CustomerException If there's an error related to customer data.
     * @throws IOException If an I/O error occurs while accessing data.
     */
    private void addBooking() throws CustomerException, IOException {
        try {
            int customerID = Integer.parseInt(customerId.getText());
            int flightID = Integer.parseInt(flightId.getText());

            Command addBookingCommand = new AddBooking(customerID, flightID);
            addBookingCommand.execute(mw.getFlightBookingSystem());

            FlightBookingSystemData.store(mw.getFlightBookingSystem());

            // Close the AddBookingWindow after successfully adding a booking
            setVisible(false);
        } catch (FlightBookingSystemException ex) {
            JOptionPane.showMessageDialog(this, ex, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
