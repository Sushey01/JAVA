package bcu.cmp5332.bookingsystem.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FlightTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
