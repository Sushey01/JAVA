package bcu.cmp5332.bookingsystem.commands;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Iterator;

import bcu.cmp5332.bookingsystem.main.CustomerException;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Booking;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

/**
 * The AddBooking class implements the Command interface and is used to add a new booking
 * to the flight booking system.
 * It associates a customer with a flight, creating a booking if the conditions are met.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class AddBooking implements Command {

    private int customer_id;
    private int flight_id;

    /**
     * Constructs an AddBooking command with the specified customer and flight IDs.
     *
     * @param customer_id The ID of the customer making the booking.
     * @param flight_id The ID of the flight to be booked.
     */
    public AddBooking(int customer_id, int flight_id) {
        this.customer_id = customer_id;
        this.flight_id = flight_id;
    }

    /**
     * Executes the AddBooking command. This method performs the following steps:
     * 1. Retrieves the customer and flight using their IDs.
     * 2. Checks if either the customer or flight has been removed.
     * 3. Checks if a booking already exists for the given customer and flight.
     * 4. Calculates the dynamic price for the booking.
     * 5. Checks if the flight has remaining capacity and has not yet departed.
     * 6. Adds the booking to the system if all conditions are met.
     *
     * @param flightBookingSystem The flight booking system where the booking will be added.
     * @throws FlightBookingSystemException If an error occurs while accessing the flight booking system.
     * @throws CustomerException If an error occurs while accessing customer data.
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException, CustomerException {
        Customer customer = flightBookingSystem.getCustomerByID(customer_id);
        Flight flight = flightBookingSystem.getFlightByID(flight_id);

        if (customer.isRemoved() || flight.isRemoved()) {
            System.out.println("Can't book a flight because the account is already removed.");
            return;
        }

        for (Booking booking : flightBookingSystem.getBookings()) {
            if (booking.getCustomer() == customer && booking.getFlight() == flight) {
                System.out.println("This booking already exists");
                return;
            }
        }

        int maxId = 0;
        if (flightBookingSystem.getBookings().size() > 0) {
            int lastIndex = flightBookingSystem.getBookings().size() - 1;
            maxId = flightBookingSystem.getBookings().get(lastIndex).getId();
        }
        double adjustedPrice = Booking.calculateDynamicPrice(flight);
        if (LocalDate.now().isBefore(flight.getDepartureDate()) || LocalDate.now().isEqual(flight.getDepartureDate())) {
            if (flight.getRemainingCapacity() > 0) {
                Booking booking = new Booking(++maxId, customer, flight, LocalDate.now(), adjustedPrice);
                flightBookingSystem.addBooking(booking);
                System.out.println("Booking success #" + customer.getId() + " - " + customer.getName() + " Flight No#" + flight.getId());
            } else {
                System.out.println("This flight is already full and cannot be booked.");
            }
        } else {
            System.out.println("Couldn't book a flight that has already expired!");
        }
    }
}
