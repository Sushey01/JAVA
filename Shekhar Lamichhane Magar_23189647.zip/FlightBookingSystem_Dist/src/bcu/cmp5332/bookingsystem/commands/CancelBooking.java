package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.CustomerException;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Booking;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

/**
 * The CancelBooking class implements the Command interface and is used to cancel a booking
 * for a customer on a specific flight in the flight booking system.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class CancelBooking implements Command {
    
    private int customer_id;
    private int flight_id;
    
    /**
     * Constructs a CancelBooking command with the specified customer ID and flight ID.
     *
     * @param customer_id The ID of the customer whose booking is to be canceled.
     * @param flight_id The ID of the flight for which the booking is to be canceled.
     */
    public CancelBooking(int customer_id, int flight_id) {
        this.customer_id = customer_id;
        this.flight_id = flight_id;
    }
    
    /**
     * Executes the CancelBooking command. This method performs the following steps:
     * 1. Retrieves the customer and flight using their IDs.
     * 2. Checks if either the customer or flight has been removed.
     * 3. Searches for the booking matching the customer and flight IDs.
     * 4. Calculates the cancellation fee based on the difference between the dynamic price
     *    and the original price of the flight.
     * 5. Cancels the booking from the flight booking system, updates customer records, and
     *    removes the customer from the flight's passenger list.
     * 6. Prints a confirmation message upon successful cancellation.
     *
     * @param flightBookingSystem The flight booking system from which the booking will be canceled.
     * @throws CustomerException If an error occurs while accessing customer data.
     * @throws FlightBookingSystemException If an error occurs while accessing the flight booking system.
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws CustomerException, FlightBookingSystemException {
        Customer customer = flightBookingSystem.getCustomerByID(customer_id);
        Flight flight = flightBookingSystem.getFlightByID(flight_id);
        
        if (customer.isRemoved() || flight.isRemoved()) {
            System.out.println("Can't cancel a flight because the account is already removed.");
            return;
        }
        
        for (Booking booking : flightBookingSystem.getBookings()) {
            if (booking.getCustomer().getId() == customer_id && booking.getFlight().getId() == flight_id) {
                double cancellationFee = Booking.calculateDynamicPrice(flight) - flight.getPrice();
                flightBookingSystem.cancelBooking(booking);
                customer.cancelBooking(booking);
                flight.removePassenger(customer);
                System.out.println("Successfully canceled booking #" + booking.getId() + " for Customer #" + customer_id +
                        " on Flight #" + flight_id + " Cancellation Fee: $" + cancellationFee);
                return;
            }
        }
        
        System.out.println("No booking found for Customer #" + customer_id + " on Flight #" + flight_id);
    }
}
