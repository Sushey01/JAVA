package bcu.cmp5332.bookingsystem.commands;

import java.time.LocalDate;
import java.util.List;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

/**
 * The ShowFlight class implements the Command interface and is used to display detailed information
 * about a specific flight in the flight booking system.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class ShowFlight implements Command {
    
    private int id;
    
    /**
     * Constructs a ShowFlight object with the specified flight ID.
     *
     * @param id The ID of the flight to display.
     */
    public ShowFlight(int id) {
        this.id = id;
    }
    
    /**
     * Executes the ShowFlight command by retrieving and printing detailed information
     * about the flight with the specified ID.
     *
     * @param flightBookingSystem The flight booking system from which flight data will be retrieved.
     * @throws FlightBookingSystemException If an error occurs while accessing flight data.
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException  {
        List<Flight> flights = flightBookingSystem.getFlights();
        try {
            Flight flight = flights.get(this.id);
            if (flight.isRemoved()) {
                System.out.println("The flight with ID " + this.id + " has been removed.");
            } else if (flight.getDepartureDate().isBefore(LocalDate.now())) {
                System.out.println("The flight with ID " + this.id + " has already departed.");
            } else {
                System.out.println(flight.getDetailsLong());
            }
        } catch (IndexOutOfBoundsException ex) {
            System.out.println("Invalid ID of flight");
        }
    }
}
