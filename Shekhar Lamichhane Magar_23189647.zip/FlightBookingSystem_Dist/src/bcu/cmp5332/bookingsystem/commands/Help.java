package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

/**
 * The Help class implements the Command interface and is responsible for displaying
 * a help message with available commands in the flight booking system.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class Help implements Command {

    /**
     * Executes the Help command by printing out the predefined help message containing
     * a list of available commands and their descriptions.
     *
     * @param flightBookingSystem The flight booking system to which the help message applies.
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) {
        System.out.println(Command.HELP_MESSAGE);
    }
}
