package bcu.cmp5332.bookingsystem.commands;

import java.util.List;

import bcu.cmp5332.bookingsystem.main.CustomerException;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

/**
 * The ListCustomers class implements the Command interface and is used to list all active customers
 * in the flight booking system.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class ListCustomers implements Command {

    /**
     * Executes the ListCustomers command. This method retrieves the list of customers from the flight
     * booking system and prints details for each active customer, including their short details.
     * It also prints the total number of active customers.
     *
     * @param flightBookingSystem The flight booking system from which customer data will be retrieved.
     * @throws CustomerException If an error occurs while accessing customer data.
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws CustomerException {
        List<Customer> customers = flightBookingSystem.getCustomers();
        int counter = 0;
        for (Customer customer : customers) {
            if (!customer.isRemoved()) {
                counter++;
                System.out.println(customer.getDetailsShort());
            }
        }
        System.out.println(counter + " customer(s)");
    }
}
