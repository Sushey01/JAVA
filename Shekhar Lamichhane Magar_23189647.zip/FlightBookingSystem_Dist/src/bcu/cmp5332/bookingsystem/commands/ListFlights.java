package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

import java.time.LocalDate;
import java.util.List;

/**
 * The ListFlights class implements the Command interface and is used to list all active flights
 * in the flight booking system that have not yet departed.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class ListFlights implements Command {

    /**
     * Executes the ListFlights command. This method retrieves the list of flights from the flight
     * booking system and prints details for each active flight that has not yet departed.
     * It also prints the total number of active flights meeting the criteria.
     *
     * @param flightBookingSystem The flight booking system from which flight data will be retrieved.
     * @throws FlightBookingSystemException If an error occurs while accessing flight data.
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        List<Flight> flights = flightBookingSystem.getFlights();
        int counter = 0;
        for (Flight flight : flights) {
            if (!flight.isRemoved() && flight.getDepartureDate().isAfter(LocalDate.now())) {
                counter++;
                System.out.println(flight.getDetailsShort());
            }
        }
        System.out.println(counter + " flight(s)");
    }
}
