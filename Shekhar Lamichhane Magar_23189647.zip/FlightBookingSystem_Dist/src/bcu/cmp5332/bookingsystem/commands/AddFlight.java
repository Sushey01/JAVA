package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;
import java.time.LocalDate;

/**
 * The AddFlight class implements the Command interface and is used to add a new flight
 * to the flight booking system.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class AddFlight implements Command {

    private final String flightNumber;
    private final String origin;
    private final String destination;
    private final double price;
    private final int capacity; 
    private final LocalDate departureDate;

    /**
     * Constructs an AddFlight command with the specified flight details.
     *
     * @param flightNumber The flight number.
     * @param origin The origin airport.
     * @param destination The destination airport.
     * @param price The price of the flight.
     * @param capacity The capacity of the flight.
     * @param departureDate The departure date of the flight.
     */
    public AddFlight(String flightNumber, String origin, String destination, double price, int capacity, LocalDate departureDate) {
        this.flightNumber = flightNumber;
        this.origin = origin;
        this.destination = destination;
        this.price = price;
        this.capacity = capacity;
        this.departureDate = departureDate;
    }
    
    /**
     * Executes the AddFlight command. This method performs the following steps:
     * 1. Retrieves the current highest flight ID from the flight booking system.
     * 2. Creates a new flight with a unique ID.
     * 3. Adds the new flight to the flight booking system.
     * 4. Prints a confirmation message with the new flight's details.
     *
     * @param flightBookingSystem The flight booking system where the flight will be added.
     * @throws FlightBookingSystemException If an error occurs while accessing the flight booking system.
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        int maxId = 0;
        if (flightBookingSystem.getFlights().size() > 0) {
            int lastIndex = flightBookingSystem.getFlights().size() - 1;
            maxId = flightBookingSystem.getFlights().get(lastIndex).getId();
        }
        System.out.println("The flight price is = " + price);
        Flight flight = new Flight(++maxId, flightNumber, origin, destination, price, capacity, departureDate);
        flightBookingSystem.addFlight(flight);
        System.out.println("Flight #" + flight.getId() + " added.");
    }
}
