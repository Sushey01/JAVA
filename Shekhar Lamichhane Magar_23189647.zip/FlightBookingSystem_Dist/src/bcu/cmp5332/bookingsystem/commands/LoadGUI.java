package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;
import bcu.cmp5332.bookingsystem.gui.MainWindow;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;

/**
 * The LoadGUI class implements the Command interface and is used to load the graphical user interface (GUI)
 * of the flight booking system.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class LoadGUI implements Command {

    /**
     * Executes the LoadGUI command by creating a new instance of the MainWindow class,
     * which initializes and displays the graphical user interface for the flight booking system.
     *
     * @param flightBookingSystem The flight booking system for which the GUI will be loaded.
     * @throws FlightBookingSystemException If an error occurs while loading the GUI.
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        new MainWindow(flightBookingSystem);
    }
}
