package bcu.cmp5332.bookingsystem.commands;

import java.util.List;

import bcu.cmp5332.bookingsystem.main.CustomerException;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

/**
 * The ShowCustomer class implements the Command interface and is used to display detailed information
 * about a specific customer in the flight booking system.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class ShowCustomer implements Command {
    
    private int id;
    
    /**
     * Constructs a ShowCustomer object with the specified customer ID.
     *
     * @param id The ID of the customer to display.
     */
    public ShowCustomer(int id) {
        this.id = id;
    }
    
    /**
     * Executes the ShowCustomer command by retrieving and printing detailed information
     * about the customer with the specified ID.
     *
     * @param flightBookingSystem The flight booking system from which customer data will be retrieved.
     * @throws CustomerException If an error occurs while accessing customer data.
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws CustomerException {
        try {
            List<Customer> customers = flightBookingSystem.getCustomers();
            Customer customer = customers.get(this.id);
            if (!customer.isRemoved()) {
                System.out.println(customer.getDetailsLong());
            }
        } catch (IndexOutOfBoundsException ex) {
            System.out.println("Invalid ID of customer");
        }
    }
}
