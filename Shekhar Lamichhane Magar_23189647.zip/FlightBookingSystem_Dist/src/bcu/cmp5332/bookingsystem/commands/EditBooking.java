package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.CustomerException;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

/**
 * The EditBooking class implements the Command interface and is used to update an existing booking
 * in the flight booking system.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class EditBooking implements Command {

    /**
     * Executes the EditBooking command. This method is not implemented in this class and is intended
     * to be implemented to update a booking in the flight booking system.
     *
     * @param flightBookingSystem The flight booking system where the booking will be updated.
     * @throws FlightBookingSystemException If an error occurs while accessing the flight booking system.
     * @throws CustomerException If an error occurs while accessing customer data.
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException, CustomerException {
        // TODO: Implement the logic to edit/update a booking in the flight booking system.
        // Example: Retrieve booking details, modify booking information, update system records, etc.
    }
}
