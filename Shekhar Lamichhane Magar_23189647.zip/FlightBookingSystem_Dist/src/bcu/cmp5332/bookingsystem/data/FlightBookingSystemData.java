package bcu.cmp5332.bookingsystem.data;

import bcu.cmp5332.bookingsystem.main.CustomerException;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * The FlightBookingSystemData class manages loading and storing of data for a flight booking system.
 * It initializes and utilizes instances of various DataManager implementations to handle different data types.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class FlightBookingSystemData {
    
    private static final List<DataManager> dataManagers = new ArrayList<>();
    
    /**
     * Static initializer block that adds DataManager instances to handle different data types.
     * Uncomment the lines for CustomerDataManager and BookingDataManager when their implementations are complete.
     */
    static {
        dataManagers.add(new FlightDataManager());
        // Uncomment the lines below when implementations are complete
        // dataManagers.add(new CustomerDataManager());
        // dataManagers.add(new BookingDataManager());
    }
    
    /**
     * Loads data into a new FlightBookingSystem instance using registered DataManagers.
     *
     * @return A FlightBookingSystem instance populated with loaded data.
     * @throws FlightBookingSystemException If there's an error specific to the flight booking system.
     * @throws IOException If an I/O error occurs while loading data.
     * @throws CustomerException If there's an error specific to customers.
     */
    public static FlightBookingSystem load() throws FlightBookingSystemException, IOException, CustomerException {
        FlightBookingSystem fbs = new FlightBookingSystem();
        for (DataManager dm : dataManagers) {
            dm.loadData(fbs);
        }
        return fbs;
    }

    /**
     * Stores data from a FlightBookingSystem instance using registered DataManagers.
     *
     * @param fbs The FlightBookingSystem instance from which data will be stored.
     * @throws IOException If an I/O error occurs while storing data.
     */
    public static void store(FlightBookingSystem fbs) throws IOException {
        for (DataManager dm : dataManagers) {
            dm.storeData(fbs);
        }
    }
    
}
