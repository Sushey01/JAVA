package bcu.cmp5332.bookingsystem.data;

import bcu.cmp5332.bookingsystem.main.CustomerException;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

import java.io.IOException;

/**
 * The DataManager interface defines methods for loading and storing data to/from a flight booking system.
 * Implementing classes handle specific data types such as customers, flights, or bookings.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public interface DataManager {
    
    /**
     * Separator used in data files to separate different fields.
     */
    public static final String SEPARATOR = "::";
    
    /**
     * Loads data from a data source into the flight booking system.
     *
     * @param fbs The FlightBookingSystem instance to which data will be loaded.
     * @throws IOException If an I/O error occurs while reading the data.
     * @throws FlightBookingSystemException If there's an error specific to the flight booking system.
     * @throws CustomerException If there's an error specific to customers.
     */
    public void loadData(FlightBookingSystem fbs) throws IOException, FlightBookingSystemException, CustomerException;
    
    /**
     * Stores data from the flight booking system into a data source.
     *
     * @param fbs The FlightBookingSystem instance from which data will be stored.
     * @throws IOException If an I/O error occurs while writing the data.
     */
    public void storeData(FlightBookingSystem fbs) throws IOException;
    
}
