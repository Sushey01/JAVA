package bcu.cmp5332.bookingsystem.data;

import bcu.cmp5332.bookingsystem.main.CustomerException;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * The CustomerDataManager class implements the DataManager interface to handle loading and storing
 * customer data from/to a text file.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class CustomerDataManager implements DataManager {

    private final String RESOURCE = "./resources/data/customers.txt";
    private final String SEPARATOR = ";";

    /**
     * Loads customer data from a text file and adds them to the flight booking system.
     *
     * @param fbs The FlightBookingSystem instance to which the loaded customers will be added.
     * @throws IOException If an I/O error occurs while reading the file.
     * @throws CustomerException If there's an error with customer data.
     */
    @Override
    public void loadData(FlightBookingSystem fbs) throws IOException, CustomerException {
        try (Scanner sc = new Scanner(new File(RESOURCE))) {
            int line_idx = 1;
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] properties = line.split(SEPARATOR, -1);
                try {
                    int id = Integer.parseInt(properties[0]);
                    String name = properties[1];
                    String phone = properties[2];
                    String email = properties[3];
                    Boolean isRemoved = Boolean.parseBoolean(properties[4]);
                    Customer customer = new Customer(id, name, phone, email, isRemoved);
                    fbs.addCustomer(customer);
                } catch (NumberFormatException ex) {
                    throw new CustomerException("Unable to parse customer ID " + properties[0] + " on line " + line_idx
                            + "\nError: " + ex);
                }
                line_idx++;
            }
        }
    }

    /**
     * Stores customer data from the flight booking system into a text file.
     *
     * @param fbs The FlightBookingSystem instance from which customers will be stored.
     * @throws IOException If an I/O error occurs while writing to the file.
     */
    @Override
    public void storeData(FlightBookingSystem fbs) throws IOException {
        try (PrintWriter out = new PrintWriter(new FileWriter(RESOURCE))) {
            for (Customer customer : fbs.getCustomers()) {
                out.print(customer.getId() + SEPARATOR);
                out.print(customer.getName() + SEPARATOR);
                out.print(customer.getPhone() + SEPARATOR);
                out.print(customer.getEmail() + SEPARATOR);
                out.print(customer.isRemoved() + SEPARATOR);
                out.println();
            }
        }
    }
}
