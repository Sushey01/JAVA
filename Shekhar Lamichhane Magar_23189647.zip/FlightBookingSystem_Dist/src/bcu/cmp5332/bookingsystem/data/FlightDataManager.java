package bcu.cmp5332.bookingsystem.data;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.Scanner;

/**
 * The FlightDataManager class implements the DataManager interface to manage
 * loading and storing of flight data for a flight booking system.
 * It reads flight data from a text file and writes flight data to the same file.
 * 
 * <p>Authors: Krishu Karki, Shekhar Lamichhane</p>
 */
public class FlightDataManager implements DataManager {

    private final String RESOURCE = "./resources/data/flights.txt";

    /**
     * Loads flight data from the specified resource file into the FlightBookingSystem instance.
     * Each line in the file represents a flight record with fields separated by SEPARATOR.
     *
     * @param fbs The FlightBookingSystem instance into which flight data will be loaded.
     * @throws IOException If an I/O error occurs while reading the file.
     * @throws FlightBookingSystemException If there's an error specific to the flight booking system.
     */
    @Override
    public void loadData(FlightBookingSystem fbs) throws IOException, FlightBookingSystemException {
        try (Scanner sc = new Scanner(new File(RESOURCE))) {
            int line_idx = 1;
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] properties = line.split(SEPARATOR, -1);
                try {
                    int id = Integer.parseInt(properties[0]);
                    String flightNumber = properties[1];
                    String origin = properties[2];
                    String destination = properties[3];
                    double price = Double.parseDouble(properties[4]);
                    int capacity = Integer.parseInt(properties[5]);
                    LocalDate departureDate = LocalDate.parse(properties[6]);
                    Boolean isRemoved = Boolean.parseBoolean(properties[7]);
                    Flight flight = new Flight(id, flightNumber, origin, destination, price, capacity, departureDate, isRemoved);
                    fbs.addFlight(flight);
                } catch (NumberFormatException ex) {
                    throw new FlightBookingSystemException("Unable to parse flight id " + properties[0] + " on line " + line_idx
                            + "\nError: " + ex);
                }
                line_idx++;
            }
        }
    }

    /**
     * Stores flight data from the FlightBookingSystem instance into the specified resource file.
     * Each flight record is written as a line in the file with fields separated by SEPARATOR.
     *
     * @param fbs The FlightBookingSystem instance from which flight data will be stored.
     * @throws IOException If an I/O error occurs while writing to the file.
     */
    @Override
    public void storeData(FlightBookingSystem fbs) throws IOException {
        try (PrintWriter out = new PrintWriter(new FileWriter(RESOURCE))) {
            for (Flight flight : fbs.getFlights()) {
                out.print(flight.getId() + SEPARATOR);
                out.print(flight.getFlightNumber() + SEPARATOR);
                out.print(flight.getOrigin() + SEPARATOR);
                out.print(flight.getDestination() + SEPARATOR);
                out.print(flight.getPrice() + SEPARATOR);
                out.print(flight.getCapacity() + SEPARATOR);
                out.print(flight.getDepartureDate() + SEPARATOR);
                out.print(flight.isRemoved() + SEPARATOR);
                out.println();
            }
        }
    }
}
